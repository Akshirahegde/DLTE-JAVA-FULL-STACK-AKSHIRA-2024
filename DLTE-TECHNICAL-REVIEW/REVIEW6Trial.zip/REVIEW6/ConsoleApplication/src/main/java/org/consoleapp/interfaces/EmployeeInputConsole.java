package org.consoleapp.interfaces;

public interface EmployeeInputConsole {
}
