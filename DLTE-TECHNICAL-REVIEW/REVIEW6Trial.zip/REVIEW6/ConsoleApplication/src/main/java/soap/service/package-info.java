@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.soap/")
package soap.service;
