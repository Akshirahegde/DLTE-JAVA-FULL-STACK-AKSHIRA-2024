package com.jpa.taskjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
