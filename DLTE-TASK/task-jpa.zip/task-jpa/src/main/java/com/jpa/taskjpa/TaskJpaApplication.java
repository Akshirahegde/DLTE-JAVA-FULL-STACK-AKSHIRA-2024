package com.jpa.taskjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskJpaApplication.class, args);
    }

}
