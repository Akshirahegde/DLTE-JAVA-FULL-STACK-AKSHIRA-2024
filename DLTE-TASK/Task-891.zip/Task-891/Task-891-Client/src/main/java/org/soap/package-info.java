@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.org/")
package org.soap;
